const express=require('express');
const mongoose=require('mongoose');
const port = 3000;

const app=express();


const dbURI="mongodb://127.0.0.1:27017/red_AirDB";


const connectionParams={
    useNewUrlParser:true,
    useUnifiedTopology:true
};

mongoose.connect(dbURI,connectionParams).then(()=>{
    console.log('database connected');
}).catch((e)=>{
    console.log(e);
});

app.use(express.json());

app.use('/', require('./routes'));

app.use((err,req,res,next)=>{
    const errorStatus=err.status || 500
    const errorMessage=err.message || "Something went wrong"
    return res.status(errorStatus).json({
        success:false,
        status:errorStatus,
        message:errorMessage,
        stack:err.stack,
    })
})

app.listen(port,(req,res)=>{
    console.log('server running on port:', port);
})