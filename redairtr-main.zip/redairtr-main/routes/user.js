const express=require('express');
const router = express.Router();
const userController = require('../controllers/user_controller');


router.post('/adduser',userController.addUser);

router.get('/getuser',userController.getUser);


router.get("/login",userController.userLogin);

router.get('/:id',userController.getUserById);

module.exports=router;