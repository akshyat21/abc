const express = require('express');
const router = express.Router();
const reservationController = require('../controllers/reservation_controller');

router.post('/addreservation',reservationController.addReservation);

module.exports = router;