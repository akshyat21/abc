const express = require('express');
const router = express.Router();
const flightController = require('../controllers/flight_controller');

router.post('/addflight',flightController.addFlight);

router.get('/getflight',flightController.getFlight);

router.delete('/:id',flightController.deleteFlight);

router.put('/:id', flightController.updateFlight);

router.get('/specific',flightController.getSpecificFlight);

module.exports = router;