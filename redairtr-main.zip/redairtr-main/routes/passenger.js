const express = require('express');
const router = express.Router();
const passengerController = require('../controllers/passenger_controller');

router.get('/all',passengerController.getAllPassengers);

router.get('/specificp',passengerController.getSpecificPassenger);

router.post('/addpassenger',passengerController.addPassenger);

router.put('/findpassengerandup/:id',passengerController.findPassengerAndUpdate);



module.exports = router;