const express = require('express');
const passenger = require('../models/passenger');
const Flight = require("../models/flight");
const reservation = require('../models/reservation');

module.exports.getAllPassengers = (req,res)=> {
    passenger.find()
        .then(passengers=> res.json(passengers))
        .catch(err=>res.status(404).json({msg:"no passengers"}));
};

module.exports.getSpecificPassenger = async (req,res)=>{
    try{
      const {
        passenger
       } = req.body;
  
       console.log(req.body.passenger_name);
       console.log(passenger);
  
       const passengers = await passenger.findOne({ passenger_name:req.body.passenger_name});
  
       console.log(passengers);
  
  
    }catch (error) {
      res.status(400).send({ err: "Something went wrong please try again" });
    }
  
  };

module.exports.addPassenger = async (req, res) => {

    passenger.create(req.body)
        .then(passenger => res.json({ msg: 'passenger added successfully' }))
        .catch(err => res.status(400).json({ error: 'Unable to add this data' }));

    console.log(req.body.flightid);
    let seatsav;
    
    const flight = await Flight.findOne({flightid:req.body.flightid});
    // console.log(flight.seatsAvailable);
    seatsav=flight.seatsAvailable - 1;
    flight.seatsAvailable -= 1;
    console.log(flight.seatsAvailable);

    flight.save();

};

module.exports.findPassengerAndUpdate =  (req, res) => {
    passenger.findByIdAndUpdate(req.params._id, req.body)
        .then(passenger => res.json({ msg: 'Updated successfully' }))
        .catch(err =>
            res.status(400).json({ error: 'Unable to update the Database' })
        );
};