const express=require('express');
const Flight=require("../models/flight");

module.exports.addFlight = (req,res)=>{
    Flight.create(req.body)
        .then(Flight=>res.json({msg:"flight added sucessfully"}))
        .catch(err=>res.status(400).json({error:"unable to add flight"}));

}

module.exports.getFlight = (req,res)=>{
    Flight.find().then(Flight=>res.json(Flight))
    .catch(err=>res.status(404).json({msg:"no flights"}));
};

module.exports.deleteFlight = (req,res)=>{
    Flight.findByIdAndRemove(req.params.id,req.body)
     .then(Flight=>res.json({msg:"deleted"}))
    .catch(err=>res.status(404).json({error:"No such flight"}));
};

module.exports.updateFlight = (req, res) => {
    Flight.findByIdAndUpdate(req.params.id, req.body)
      .then(Flight => res.json({ msg: 'Updated successfully' }))
      .catch(err =>
        res.status(400).json({ error: 'Unable to update the Database' })
      );
};

module.exports.getSpecificFlight = async (req,res)=>{
    try{
      const {
        From, To,dateo
       } = req.body;
  
       console.log(req.body);
  
       const flights = await Flight.findOne({ From: From,To:To,dept:dateo });
  
       console.log(flights);
  
  
    }catch (error) {
      res.status(400).send({ err: "Something went wrong please try again" });
    }
  
};