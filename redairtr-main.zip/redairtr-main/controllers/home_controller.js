const express = require('express');

module.exports.home = (req,res) => {
    try{

        res.json({msg: 'Home Page rendering sucessfully'}).status(200)

    }catch(err){
        console.log('Error:',err);
    }
}